<?php 
    /**
     *  网站域名，要带http
     * @var unknown
     */
   define('WEBSITE','http://wx.dgcf.org');
   /**APPID：绑定支付的APPID**/
   define('APP_ID','wx7999eefe68b877c9');
   /** MCHID：商户号（必须配置，开户邮件中可查看）**/
   define('MERCHANT_ID','1483146632');
   /**KEY：商户支付密钥**/
   define('KEY','dongguanshicishanhui076922222628');
   /**APPSECRET：公众帐号secert（**/
   define('APP_SECRET','4683cb977b2de8ca2f5ced7f87d5a70e');
   
   /**数据库host**/
   define('DB_HOST','172.18.114.243');
   /**数据库名**/
   define('DB_NAME','pic-wxpay');
   /**数据库用户名**/
   define('DB_USER','root');
   /**数据库密码**/
   define('DB_PASS','iTM59at7o;C1om');
?>