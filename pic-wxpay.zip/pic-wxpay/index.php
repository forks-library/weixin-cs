<?php
require_once './config.php';

$pictureorder=$_GET['pictureorder'];
if(empty($pictureorder)){
    $pictureorder = '';
}
header("Location:".WEBSITE."/pic-wxpay/wx-pay/example/wxlogin.php?pictureorder=".$pictureorder);